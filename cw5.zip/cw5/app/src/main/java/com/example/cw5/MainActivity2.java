package com.example.cw5;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        TextView na = findViewById(R.id.textView);
        TextView age = findViewById(R.id.textView2);
        Button Back = findViewById(R.id.button);

        Bundle Get = getIntent().getExtras();
        String Name = Get.getString("name");
        String Age = Get.getString("age");


        na.setText("Your name is "+Name);
        age.setText("Your age is " +Age);


        Back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

}